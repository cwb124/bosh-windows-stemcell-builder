# BOSH.Agent

Powershell module to install bosh-agent for a given IAAS

```
Install-Agent -IaaS $IaaS -AgentZipPath (Join-Path $PSScriptRoot 'agent.zip')
```
